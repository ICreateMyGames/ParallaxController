﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxController : MonoBehaviour {

    public HorizontalDirection horizontalDirection;

    public bool randomizeStart;
    public FloatReference speedMultiplier;

    public MoveType moveType;

    [Header("Only for follow transform")]
    public Transform transformToFollow;
    public VerticalDirection verticalDirection;

    private List<ParallaxImage> images;
    private float lastX;
    private float lastY;

    private void Start() {
        InitController();
    }

#if UNITY_EDITOR
    public void Update() {
        if (Input.GetKeyDown(KeyCode.Return)) {
            InitController();
        }
    }
#endif


    private void FixedUpdate() {
        if (images == null) return;

        if (moveType == MoveType.OverTime) MoveOverTime();
        else if (moveType == MoveType.FollowTransform) {
            FollowTransformX();
            FollowTransformY();
        }
    }

    private void MoveOverTime() {
        if (horizontalDirection == HorizontalDirection.Fix) return;
        foreach (var item in images) {
            item.MoveX(Time.deltaTime);
        }
    }

    private void FollowTransformY() {
        if (verticalDirection == VerticalDirection.Fix) return;

        float distance = lastY - transformToFollow.position.y;
        if (Mathf.Abs(distance) < 0.001f) return;
        foreach (var item in images) {
            item.MoveY(distance);
        }
        lastY = transformToFollow.position.y;
    }

    private void FollowTransformX() {
        if (horizontalDirection == HorizontalDirection.Fix) return;

        float distance = lastX - transformToFollow.position.x;
        if (Mathf.Abs(distance) < 0.001f) return;
        foreach (var item in images) {
            item.MoveX(distance);
        }
        lastX = transformToFollow.position.x;
    }

    private void InitController() {
        InitList();
        ScanForImages();

        foreach (var item in images) {
            item.InitImage(speedMultiplier, horizontalDirection, verticalDirection, moveType == MoveType.FollowTransform);
            if (randomizeStart) item.RandomizeStart();
        }

        if (moveType == MoveType.FollowTransform) {
            lastX = transformToFollow.position.x;
            lastY = transformToFollow.position.y;
        }

    }

    private void InitList() {
        if (images == null) images = new List<ParallaxImage>();
        else {
            foreach (var item in images) {
                item.CleanUpImage();
            }
            images.Clear();
        }
    }

    private void ScanForImages() {
        ParallaxImage pi;

        foreach (Transform child in transform) {
            if (child.gameObject.activeSelf) {
                pi = child.GetComponent<ParallaxImage>();
                if (pi != null) images.Add(pi);
            }
        }
    }

}

[System.Serializable]
public class FloatReference {
    [Range(0.01f, 5)]
    public float value = 1;
}

public enum HorizontalDirection {
    Fix,
    Left,
    Right
}

public enum VerticalDirection {
    Fix,
    Up,
    Down
}

public enum MoveType {
    OverTime,
    FollowTransform
}
