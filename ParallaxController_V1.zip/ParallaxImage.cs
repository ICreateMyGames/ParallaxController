﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxImage : MonoBehaviour {

    //public 
    public float speedX = 0;
    public float speedY = 0;
    public int spawnCount = 2;
    public float repositionBuffer = .5f;

    public ImageType imageType;
    [Header("Only for Instances")]
    public float spawnBuffer = 0;

    public bool spawnRandom = false;
    [Range(0, 5)]
    public float spawnRandomRange = 0;

    [Space]

    public bool scaleRandom = false;
    public bool freezeYBottom = true;
    [Range(1, 4)]
    public float scaleRandomRange = 0;


    //private
    private const int roundFactor = 1000;

    private Transform[] controlledTransforms;
    private float imageWidth;
    private float minLeftX;
    private float maxRightX;
    private FloatReference speedMultiplier;
    private HorizontalDirection hDir;
    private VerticalDirection vDir;
    private SpriteRenderer sr;
    private Vector3 startPos;

    private bool followTransform;

    private void Awake() {
        sr = GetComponent<SpriteRenderer>();
        startPos = transform.position;
    }

    public void RandomizeStart() {
        MoveX(Random.Range(0,imageWidth),false);
    }

    public void MoveY(float moveBy) {
        moveBy *= speedY * speedMultiplier.value;
        if (vDir == VerticalDirection.Down) moveBy *= -1;

        for (int i = 0; i < controlledTransforms.Length; i++) {
            Vector3 newPos = controlledTransforms[i].position;
            newPos.y -= moveBy;
            controlledTransforms[i].position = newPos;
        }
    }

    public void MoveX(float moveBy, bool doSpeedCalc = true) {
        if(doSpeedCalc) moveBy *= speedX * speedMultiplier.value;
        if (hDir == HorizontalDirection.Right) moveBy *= -1;

        moveBy = Mathf.Round(moveBy * roundFactor) / roundFactor;
        for (int i = 0; i < controlledTransforms.Length; i++) {
            Vector3 newPos = controlledTransforms[i].position;
            newPos.x -= moveBy;
            newPos.x = Mathf.Round(newPos.x * roundFactor) / roundFactor;
            controlledTransforms[i].position = newPos;
        }
        CheckAndReposition();
    }

    private void CheckAndReposition() {
        if (hDir == HorizontalDirection.Left || followTransform) {
            for (int i = 0; i < controlledTransforms.Length; i++) {
                if (controlledTransforms[i].position.x < minLeftX) {
                    Vector3 newPos = controlledTransforms[i].position;
                    newPos.x = GetRightmostTransform().position.x + imageWidth;
                    controlledTransforms[i].position = newPos;
                }
            }
        }
        if (hDir == HorizontalDirection.Right || followTransform) {
            for (int i = 0; i < controlledTransforms.Length; i++) {
                if (controlledTransforms[i].position.x > maxRightX) {
                    Vector3 newPos = controlledTransforms[i].position;
                    newPos.x = GetLeftmostTransform().position.x - imageWidth;
                    controlledTransforms[i].position = newPos;
                }
            }
        }

    }


    public void CleanUpImage() {
        if (controlledTransforms != null) {
            for (int i = 1; i < controlledTransforms.Length; i++) {
                Destroy(controlledTransforms[i].gameObject);
            }
        }
    }

    public void InitImage(FloatReference speedMultiplier, HorizontalDirection hDir, VerticalDirection vDir, bool followTransform) {
        this.speedMultiplier = speedMultiplier;
        this.hDir = hDir;
        this.vDir = vDir;
        this.followTransform = followTransform;

        transform.position = startPos;

        int arraySize = spawnCount;
        if (followTransform) arraySize *= 2;
        arraySize += 1;

        controlledTransforms = new Transform[arraySize];
        controlledTransforms[0] = transform;


        imageWidth = sr.bounds.size.x;
        if (imageType == ImageType.Instance) {
            imageWidth += spawnBuffer;
        }
        if (followTransform) {
            minLeftX = transform.position.x - imageWidth * (spawnCount + 1) - repositionBuffer;
            maxRightX = transform.position.x + imageWidth * (spawnCount + 1) + repositionBuffer;

        } else {
            if (hDir == HorizontalDirection.Left) {
                minLeftX = transform.position.x - imageWidth - repositionBuffer;
                maxRightX = float.PositiveInfinity;
            } else if (hDir == HorizontalDirection.Right) {
                maxRightX = transform.position.x + imageWidth + repositionBuffer;
                minLeftX = float.NegativeInfinity;
            } else if (hDir == HorizontalDirection.Fix) {
                minLeftX = float.NegativeInfinity;
                maxRightX = float.PositiveInfinity;
            }
        }


        float changeBy;
        for (int i = 1; i <= spawnCount; i++) {
            if (hDir == HorizontalDirection.Right) {
                changeBy = -imageWidth * i;
            } else {
                changeBy = imageWidth * i;
            }
            if (imageType == ImageType.Instance && spawnRandom) {
                changeBy += Random.Range(-spawnRandomRange, spawnRandomRange);
            }

            controlledTransforms[i] = PrepareCopyAt(transform.position.x + changeBy);
            if (followTransform) controlledTransforms[i + spawnCount] = PrepareCopyAt(transform.position.x - changeBy);
        }

    }

    private Transform PrepareCopyAt(float posX) {
        float posY = transform.position.y;
        Vector3 localScale = transform.localScale;

        if (imageType == ImageType.Instance && scaleRandom) {
            localScale.x = Random.Range(1, scaleRandomRange);
            if (Random.value < .5f) localScale.x = 1 / localScale.x;
            localScale.y = localScale.x;

            if (freezeYBottom) {
                posY = transform.position.y - (sr.bounds.size.y / 2) * ((transform.localScale.y - localScale.y) / transform.localScale.y);
            }
        }

        GameObject go = Instantiate(gameObject, new Vector3(posX, posY, transform.position.z), Quaternion.identity, transform.parent);
        Destroy(go.GetComponent<ParallaxImage>());
        go.transform.localScale = localScale;

        return go.transform;

    }

    private Transform GetRightmostTransform() {
        float currentMaxX = float.NegativeInfinity;
        Transform currentTransform = null;

        for (int i = 0; i < controlledTransforms.Length; i++) {
            if (currentMaxX < controlledTransforms[i].position.x) {
                currentMaxX = controlledTransforms[i].position.x;
                currentTransform = controlledTransforms[i];
            }
        }

        return currentTransform;
    }
    private Transform GetLeftmostTransform() {
        float currentMinX = float.PositiveInfinity;
        Transform currentTransform = null;

        for (int i = 0; i < controlledTransforms.Length; i++) {
            if (currentMinX > controlledTransforms[i].position.x) {
                currentMinX = controlledTransforms[i].position.x;
                currentTransform = controlledTransforms[i];
            }
        }

        return currentTransform;
    }

}

public enum ImageType {
    Seamless,
    Instance
}
